﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AutoRent.Pages.Admin
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
