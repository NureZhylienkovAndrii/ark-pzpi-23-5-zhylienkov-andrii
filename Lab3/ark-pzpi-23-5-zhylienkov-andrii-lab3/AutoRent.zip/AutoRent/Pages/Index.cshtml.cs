﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AutoRent.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
